function createTask(){
    var i = 0;
    var content = document.getElementById("task").value;
    console.log(content);
    if(content == ""){
        alert("Enter some todo content");
        return 0;
    }
    var cnt = document.createElement("li");
    cnt.setAttribute('id', "id_1");
    var t = document.createTextNode(content);
    cnt.appendChild(t);
    document.getElementById("todo_list").appendChild(cnt);
    document.getElementById("task").value = "";
}