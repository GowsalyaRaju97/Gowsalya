function createTask(){
    var content = document.getElementById("task").value;
    if(content === ""){
        alert("Enter some todo content");
        return 0;
    }
    var cnt = document.createElement("li");
    cnt.setAttribute('id',"id1");
    var t = document.createTextNode(content);
    cnt.appendChild(t);
    document.getElementById("todo_list").appendChild(cnt);
    document.getElementById("task").value = "";
}