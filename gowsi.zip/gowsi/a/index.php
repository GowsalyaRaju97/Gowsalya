<?php

require 'dbinfo.php';

$query = "SELECT full_name, u_name, pwd FROM login_details ORDER BY u_name";
$resultObj = $connection->query($query);

if(count($_POST) > 0)
{
    while($row = $resultObj->fetch_assoc())
    {
        if($_POST['uname'] != $row['u_name'])
        {
            //echo "Incorrect username. Try to signup first <br>";
            $val = false;
        }
        elseif($_POST['pwd'] != $row['pwd'])
        {
            //echo "Incorrect password. Try to signup first <br>";
            $val = false;
        }
        else{
            header('Location: login_result.php');
            $val = true;
            break;
        }

    }

    if($val === false){
        echo "Incorrect input. Try to signup first <br>";
    }
    
}

?>
<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <div class="login-form">
			<form method="post" action="index.php">
                    <h2>Login</h2>
                    <label>User Name :</label><br>
                    <input type="text" name="uname" placeholder="Enter username" required>
                    <br>
                    <br>
					<label>Password :</label><br>
					<input type="password" name="pwd" placeholder="Enter password" required>
					<br>
					<br>
                    <input type="submit" name="submit" value="SUBMIT">
                    <br><br>
                    <a href="signup.php" class="link" title="Create account">SIGNUP</a>
					<br><br><br><br><br><br><br><br>
				</form>
		</div>
    </body>
</html>
<?php

$resultObj->close();
$connection->close();

?>