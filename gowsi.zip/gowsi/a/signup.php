<?php

require 'dbinfo.php';

if(count($_POST) > 0)
{
    $fn = $_POST['fname'];
    $un = $_POST['uname'];
    $p = $_POST['pwd'];

    $sql = "SELECT DISTINCT u_name FROM login_details WHERE u_name='$un'";
    $resultObj = $connection->query($sql);
    
    while($row = $resultObj->fetch_assoc())
    {
        $user = $row['u_name'];
        
    }
    $checkuname = strcmp($un,$user);

       if($checkuname == 0)
        {
            echo "Already exist. Try another username. <br> Thank you!";
            return 0;
        }else{
            $query = "INSERT INTO login_details VALUES ('$fn', '$un', '$p')";
            $result=$connection->query($query);

            if ($connection->query($query) === TRUE) {
                print "Hi ".$fn." your new record created successfully";
            } 
            else {
                echo "Error: " . $query . "<br>" . $conn->error;
            }
        
        }

}

?>
<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <div class="login-form">
			<form method="post" action="signup.php">
					<h2>Register</h2>
					<label>Name :</label><br>
					<input type="text" name="fname" placeholder="Enter name">
					<br>
                    <br>
                    <label>Username :</label><br>
					<input type="text" name="uname" placeholder="Enter username">
					<br>
                    <br>
					<label>Password :</label><br>
					<input type="password" name="pwd" placeholder="Enter password">
					<br>
					<br>
                    <input type="submit" name="submit" value="SUBMIT">
			</form>
		</div>
    </body>
</html>
<?php


$connection->close();

?>