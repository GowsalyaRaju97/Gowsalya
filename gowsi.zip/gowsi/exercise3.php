<?php

$stringvar = 'A friend in need is a friend in deed. ';
echo $stringvar;

$friendvar = 'friend';
echo "A $friendvar in need is a $friendvar in deed.";

$number = 1;
echo "($number)st place.";
echo $number."st place.";

$varname = "It's a \"volleyball competition\".";
echo $varname;

$quote = strtoupper($stringvar);
echo $quote;

$quote = strtolower($quote);
echo $quote;

echo substr($quote, 2);
echo substr($quote, 0, -20);
echo substr($quote, -20);
echo substr($quote, 2, 7);

$quote = str_split($stringvar, 8);
print_r($quote);

$classes = array("pen","board","phone","student","Girl");
$objects = ["Gel pen","Black board","Nokia phone","Gowsalya","Pragati"];
$objectStates = array("name" => "Gowsalya",
                "10" => "21",
                "height" => "4.5",
                "52.5");

print_r($classes);
print_r($objects);
print_r($objectStates);

$lastvalue = array_pop($classes);
print $lastvalue;

array_push($classes,"boy");
print_r($classes);

echo $objectStates["name"];
echo $objectStates["10"];
echo $objectStates["height"];
echo $objectStates[11];

print count($objectStates);

$Authors = array(
    "male" => array(
        "Charles Dickem" => array("A Christmas Carol", "Oliver Twist"),
        "William Shakesphere" => array("Romeo and Juliet","Richard III")
    ),
    "female" => array(
        "L. M. Montgomery" => array("Anne of Green Gables", "Anne of Avoniea"),
        "Lousia May Alcott" => array("Little Women")
    )
);

print count($Authors["male"]["Charles Dickem"], COUNT_RECURSIVE);

print_r($Authors);
print_r($Authors["male"]);
print_r($Authors["male"]["William Shakesphere"]);
print_r($Authors["male"]["William Shakesphere"][1]);

unset($objects);
print_r($objects);

$objects = array();

$count = count($objects);
$outcome = $count ? $count : "count unavailable.";
$outcome = $count ?? "count unavailable.";
echo $outcome;

$class = array("pen","board","phone","student","Girl");

for($i = 0; $i < count($class); $i++){
    echo $class[$i];
}

foreach($objectStates as $value){
    print $value;
}

function getAuthor(){
    return "Charles Dickens";
}

$authorName = getAuthor();
echo $authorName;
?>