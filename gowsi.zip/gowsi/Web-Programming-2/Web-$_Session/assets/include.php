<?php

session_start();

$dbPassword = "gowsalyaraju";
$dbUserName = "gowsi";
$dbServer = "localhost";
$dbName = "employee";

?>