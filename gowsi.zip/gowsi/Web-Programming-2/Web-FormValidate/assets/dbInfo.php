<?php


$dbPassword = "gowsalyaraju";
$dbUserName = "gowsi";
$dbServer = "localhost";
$dbName = "employee";

$connection = new mysqli($dbServer, $dbUserName, $dbPassword, $dbName);

if($connection->connect_errno)
{
    exit("Database Connection Failed. Reason: ".$connection->connect_error);
}

$query = "SELECT id, first_name, last_name, pet_name FROM gowsalya ORDER BY first_name";
$resultObj = $connection->query($query);

?>