<?php

$connection = new mysqli($dbServer, $dbUserName, $dbPassword, $dbName);

$query = "SELECT id, first_name, last_name, pet_name FROM gowsalya ORDER BY first_name";
$resultObj = $connection->query($query);

?>