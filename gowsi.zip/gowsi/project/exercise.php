

<!DOCTYPE html>
<html>
    <head>
        <title>Webpage-Demo</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet" type="text/css">
    </head>
    <body>
    <div class="login-form">
				<form method="post" action="">
					<h2>Login</h2>
					<label>User Name :</label><br>
					<input type="text" name="uname" placeholder="Enter username" required>
					<br>
					<br>
					<label>Password :</label><br>
					<input type="password" name="pwd" placeholder="Enter password" required>
					<br>
					<br>
					<button type="button" value="submit">Login</button>
				</form>
			</div>
    </body>
</html>
