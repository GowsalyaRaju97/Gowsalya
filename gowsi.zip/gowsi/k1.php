<html>

<body>
<form action="r1.php" method="post">

empid: <input type="number" name="empid"><br>

empname: <input btype="text" name="empname"><br>

salary:<input type="number" name="email"><br>

empno:<input type="text" name="empno"><br>

address:<input type="text" name="address"><br>


<input type="submit" value="submit">

</form>
</body>
</html>


