<?php

define('CONSTANT_VAR',"I am a constant variable!");

$intvar = 1234;
$floatvar = 12.34;
$stringvar = "I am a string!";
$boolvar = false;

print "----------------------Returns TRUE--------------------------\n \n";

echo is_bool($boolvar);  echo "\n";
echo is_string($stringvar);  echo "\n";
echo is_float($floatvar);  echo "\n";
echo is_int($intvar);  echo "\n";
echo defined('CONSTANT_VAR');  echo "\n\n";

print "-----------------------Returns FALSE-------------------------\n \n";

echo is_bool($stringvar);  echo "\n";
echo is_string($floatvar);  echo "\n";
echo is_float($stringvar);  echo "\n";
echo is_int($boolvar);  echo "\n";
echo defined('NOTCONSTANT_VAR');  echo "\n\n";

?>