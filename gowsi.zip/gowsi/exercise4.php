<?php

$dbPassword = "gowsalyaraju";
$dbUserName = "gowsi";
$dbServer = "localhost";
$dbName = "employee";

$connection = new mysqli($dbServer, $dbUserName, $dbPassword, $dbName);

print_r($connection);

if($connection->connect_errno){
    exit("Database Connection Failed. Reason: ".$connection->connect_error);
}

$query = "SELECT emp_id, emp_name, salary, phone, email FROM employee_details ORDER BY emp_id";
$resultObj = $connection->query($query);

if ($resultObj->num_rows > 0){
    while ($singleRowFromQuery = $resultObj->fetch_array()){
        echo $singleRowFromQuery['emp_id']."---".$singleRowFromQuery['emp_name']."---".$singleRowFromQuery['salary']."---".$singleRowFromQuery['phone']."---".$singleRowFromQuery['email']."<br>";
    }
}

$resultObj->close();
$connection->close();
?>