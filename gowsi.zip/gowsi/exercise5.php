<html>
 
<body>
 
FirstName <?php echo $_POST["first_name"];?><br>
 
Your LastName is: <?php echo $_POST["last_name"];?><br>
 
Your petname is: <?php echo $_POST["pet_name"];?><br>
 
</body>
 
</html>

 
<?php


 
$dbPassword = "gowsalyaraju";
 
$dbUserName = "gowsi";
 
$dbServer = "localhost";
 
$dbName = "employee";

 
$connection = new mysqli($dbServer,$dbUserName,$dbPassword,$dbName);
 
//print_r($connection);

 
if($connection->connect_errno){
exit("Database connection Failed.Reason:".$connection->connect_error);
}
 
//$query = "INSERT INTO gowsalya (first_name,last_name,pet_name) Values ('theju','kumar','nuthi')";
 
//$query ="UPDATE authors SET FirstName='ganga' WHERE LastName='nuthi'";
 
$query="SELECT FirstName,LastName,penname from authors ORDER BY FirstName";
 
$resultObj = $connection->query($query);
 
if($resultObj->num_rows > 0)
 
{
 
while($singleRowFromQuery = $resultObj->fetch_array())
 
{
 
echo 
"Author: ".$singleRowFromQuery['FirstName'].PHP_EOL;
 
}
 
}
 
$resultObj->close();
 
$connection->query($query);
 
$connection->close();
 
?>